<?php 
    /**
     * *********************************************************************************************************
     * @_forProject:  Application | Developed By: TAMMA CORPORATION
     * @_purpose: (Please Specify) 
     * @_version Release: package_two
     * @_created Date: 00/00/2019
     * @_author(s):
     *   1) Mr. Michael kaiva Nimley. (Hercules d Newbie)
     *      @contact Phone: (+231) 777-007-009
     *      @contact Mail: michaelkaivanimley.com@gmail.com, mnimley6@gmail.com, mnimley@tammacorp.com
     *   --------------------------------------------------------------------------------------------------
     *   2) Fullname of engineer. (Code Name)
     *      @contact Phone: (+231) 000-000-000
     *      @contact Mail: -----@tammacorp.com
     * *********************************************************************************************************
     */
    require_once('../db.inc.php');
    
    /**
    * undocumented class
    *
    * @package default
    * @author 
    **/
    class AdminPortal
    {
        /**
         * undocumented function
         *
         * @return void
         * @author 
         **/
         public function __construct()
         {
            $this->getCurriculumData();
            $this->deleteCurriculumData();
            $this->inputCurriculumData();
            $this->fileUpload();
            $this->fileDelete();
         }
        //  
         private function inputCurriculumData() 
         {
            if (isset($_POST['addData'])) {
                $subject                 =   htmlspecialchars($_POST['subject']);
                $semester                =   htmlspecialchars($_POST['semester']);
                $grade                   =   htmlspecialchars($_POST['grade']);
                $period                  =   htmlspecialchars($_POST['period']);
                $topic                   =   htmlspecialchars($_POST['topic']);
                $learning_outcome        =   htmlspecialchars($_POST['learning_outcome']);
                $objectives              =   htmlspecialchars($_POST['objectives']);
                $contents                =   htmlspecialchars($_POST['contents']);
                $activities              =   htmlspecialchars($_POST['activities']);
                $materials               =   htmlspecialchars($_POST['materials']);
                $competency_assessment   =   htmlspecialchars($_POST['competency_assessment']);
                $files                   =   htmlspecialchars($_POST['files']);
                
                $files = explode(';', $files);
                $files = array_unique($files);
                $files = implode(";", $files);

                // Edit Existing
                if ( isset($_POST['edit']) && !empty($_POST['edit']) ) {
                    $id = htmlspecialchars(addslashes($_POST['edit']));
                    // 
                    $update = database::$conn->query("SELECT `files`, `id` FROM `curriculum` WHERE id = '$id' ");

                    $data = $update->fetch_object();
                    $filesUpdate = $data->files .= $files;

                    // 
                    $query = database::$conn->query(" UPDATE `curriculum` SET
                        `files` = '$filesUpdate',
                        `subject` = '$subject',
                        `semester` = '$semester',
                        `grade` = '$grade',
                        `period` = '$period',
                        `topic` = '$topic',
                        `learning_outcome` = '$learning_outcome',
                        `objectives` = '$objectives',
                        `contents` = '$contents',
                        `activities` = '$activities',
                        `materials` = '$materials',
                        `competency_assessment` = '$competency_assessment'
                        WHERE 
                            id = '$id'
                    ");
                    // 
                    if ($query == false) {
                        $response =  json_encode([
                            'status' => false,
                            'message' => 'Sorry curriculum and course materials could not be updated '. database::$conn->error
                        ], JSON_PRETTY_PRINT);
                    } else {
                        // 
                        if ( database::$conn->affected_rows == 1 ) {
                            $response =  json_encode([
                                'status' => true,
                                'message' => '1 record was just updated '
                            ], JSON_PRETTY_PRINT);
                        } else {
                            $response =  json_encode([
                                'status' => false,
                                'message' => 'Sorry curriculum and course materials could not updated'
                            ], JSON_PRETTY_PRINT);
                        }
                    }
                } 
                // Add New
                else {
                    // 
                    $query = database::$conn->query(" INSERT INTO `curriculum` (
                        `files`,
                        `subject`,
                        `semester`,
                        `grade`,
                        `period`,
                        `topic`,
                        `learning_outcome`,
                        `objectives`,
                        `contents`,
                        `activities`,
                        `materials`,
                        `competency_assessment`
                        )
                        VALUES (
                            '$files',
                            '$subject',
                            '$semester', 
                            '$grade',
                            '$period',
                            '$topic',
                            '$learning_outcome',
                            '$objectives',
                            '$contents',
                            '$activities',
                            '$materials',
                            '$competency_assessment'
                        ) 
                    ");
                    // 
                    if ($query == false) {
                        $response =  json_encode([
                            'status' => false,
                            'message' => 'Sorry curriculum and course materials could not be added '
                        ], JSON_PRETTY_PRINT);
                    } else {
                        // 
                        if ( database::$conn->affected_rows == 1 ) {
                            $response =  json_encode([
                                'status' => true,
                                'message' => '1 New record was just added'
                            ], JSON_PRETTY_PRINT);
                        } else {
                            $response =  json_encode([
                                'status' => false,
                                'message' => 'Sorry curriculum and course materials could not added'
                            ], JSON_PRETTY_PRINT);
                        }
                    }
                }
                // 
                print $response;
            }
         }
        //  
         private function getCurriculumData()
         {
             if (isset($_GET['getCurriculumData'])) 
             {  
                //  get record for edit
                 if (isset($_GET['key']) && !empty($_GET['key'])) {
                    $key = htmlspecialchars(addslashes($_GET['key']));
                    $query = database::$conn->query(" SELECT * FROM `curriculum` WHERE id = '$key' ");
                 }
                //  
                 elseif (isset($_GET['searchquery']) && !empty($_GET['searchquery'])) {
                    $searchquery = htmlspecialchars(addslashes($_GET['searchquery']));
                    $query = database::$conn->query(" SELECT * FROM `curriculum` WHERE 
                        `subject` LIKE '%$searchquery%' OR
                        -- `grade` LIKE '[$searchquery]' OR
                        `topic` LIKE '%$searchquery%'
                        -- `learning_outcome` LIKE '[$searchquery]' OR
                        -- `objectives` LIKE '[$searchquery]' OR
                        -- `contents` LIKE '[$searchquery]' OR
                        -- `activities` LIKE '[$searchquery]' OR
                        -- `competency_assessment` LIKE '[$searchquery]'
                    ");
                 } 
                //  return all - limit 100
                 else {
                    $query = database::$conn->query(" SELECT * FROM `curriculum` Order BY `semester`, `period`, `grade` ASC limit 25 ");
                 }
                 
                // 
                if ($query == false) {
                    $response =  json_encode([
                        'status' => false,
                        'message' => 'Sorry curriculum and course materials not found'
                    ], JSON_PRETTY_PRINT);
                } else {
                    if (mysqli_num_rows($query) > 0) {
                        $id = [];
                        $files = [];
                        $subject = [];
                        $semester = [];
                        $grade = [];
                        $period = [];
                        $topic = [];
                        $learning_outcome = [];
                        $objectives = [];
                        $contents = [];
                        $materials = [];
                        $competency_assessment = [];
                        // 
                        while ($row = mysqli_fetch_assoc($query)) {
                            $id[]                    =   $row["id"];
                            $files[]                 =   $row["files"];
                            $subject[]                =  htmlspecialchars_decode($row["subject"]);
                            $semester[]               =  htmlspecialchars_decode($row["semester"]);
                            $grade[]                  =  htmlspecialchars_decode($row["grade"]);
                            $period[]                 =  htmlspecialchars_decode($row["period"]);
                            $topic[]                  =  htmlspecialchars_decode($row["topic"]);
                            $learning_outcome[]       =  htmlspecialchars_decode($row["learning_outcome"]);
                            $objectives[]             =  htmlspecialchars_decode($row["objectives"]);
                            $contents[]               =  htmlspecialchars_decode($row["contents"]);
                            $activities[]             =  htmlspecialchars_decode($row["activities"]);
                            $materials[]              =  htmlspecialchars_decode($row["materials"]);
                            $competency_assessment[]  =  htmlspecialchars_decode($row["competency_assessment"]);
                        }
                        // 
                        $response = json_encode([
                            'status' => true,
                            'message' => [
                                'id'                     =>  $id,
                                'files'                  =>  $files,
                                'subject'                =>  $subject,
                                'semester'               =>  $semester,
                                'grade'                  =>  $grade,
                                'period'                 =>  $period,
                                'topic'                  =>  $topic,
                                'learning_outcome'       =>  $learning_outcome,
                                'objectives'             =>  $objectives,
                                'contents'               =>  $contents,
                                'activities'             =>  $activities,
                                'materials'              =>  $materials,
                                'competency_assessment'  =>  $competency_assessment,
                            ]
                        ], JSON_PRETTY_PRINT);
                    } else {
                        $response = json_encode([
                            'status' => false,
                            'message' => 'Sorry There are no curriculum and course materials'
                        ], JSON_PRETTY_PRINT);
                    }
                }
                
                print $response;

             }
         }
         public function fileUpload()
         {
             if (isset($_POST['fileUpload'])) {
                $extension = $_POST['extension'];
                $fileName = $_POST['fileName'];
                $fileContents = base64_decode($_POST['fileUpload']);

                file_put_contents("../uploads/".$fileName.'.'.$extension, $fileContents);

                if ( empty(file_get_contents("../uploads/".$fileName.'.'.$extension)) ) {
                    print $response =  json_encode([
                        'status' => false,
                        'message' => 'Sorry '.$fileName.' upload failed'
                    ], JSON_PRETTY_PRINT);
                } else {
                    print $response =  json_encode([
                        'status' => true,
                        'message' => [
                            "url" => "config/uploads/".$fileName.'.'.$extension,
                            "filename" => $fileName
                        ]
                    ], JSON_PRETTY_PRINT);
                }
             }
         }
         private function fileDelete() {
            if (isset($_POST['deleteFile'])) {
                // 
                $filePointer  = $_POST['fileToRemove'];
                $recordId     = $_POST['recordId'];
                // 
                $extract = database::$conn->query("SELECT `files`, `id` FROM `curriculum` WHERE id = '$recordId' ");
                // 
                if ($extract == false) {
                    $response =  json_encode([
                        'status' => false,
                        'message' => 'Sorry '.$_POST['fileToRemove']. ' could not be deleted'. database::$conn->error
                    ], JSON_PRETTY_PRINT);
                } else {
                    if ($extract->num_rows > 0) {
                        $data = $extract->fetch_object();
                        // 
                        $exisitingFileNames = explode(';', $data->files);
                        // 
                        if ( ( $key = array_search($filePointer, $exisitingFileNames) ) !== false ) {
                            unset($exisitingFileNames[$key]);
                        }
                        // 
                        $updatedFileNames = implode(';', $exisitingFileNames);
                        // 
                        $update = database::$conn->query("UPDATE `curriculum` SET files = '$updatedFileNames' WHERE id = '$recordId' ");
                        // 
                        if ($update == false) {
                            $response =  json_encode([
                                'status' => false,
                                'message' => 'Sorry '.$_POST['fileToRemove']. ' could not be deleted '. database::$conn->error
                            ], JSON_PRETTY_PRINT);
                        } else {
                            // remove file
                            unlink('uploads/'.$filePointer);
                            // 
                            $response =  json_encode([
                                'status' => true,
                                'message' => ''
                            ], JSON_PRETTY_PRINT);
                        }
                    } else {
                        $response =  json_encode([
                            'status' => false,
                            'message' => 'Sorry '.$_POST['fileToRemove']. ' could not be deleted'. database::$conn->error
                        ], JSON_PRETTY_PRINT);
                    }
                    
                }
                
                print $response;


                

            }
         }
        //  
         private function deleteCurriculumData()
         {
             if ( isset($_POST['deleteCurriculumiItem']) && !empty($_POST['deleteCurriculumiItem']) ) {
                // 
                $id = htmlspecialchars(addslashes($_POST['deleteCurriculumiItem']));
                // 
                $query = database::$conn->query(" DELETE FROM `curriculum` WHERE `id` = '$id' ");
                // 
                if ($query == false) {
                    print $response =  json_encode([
                        'status' => false,
                        'message' => 'Sorry this curriculum item could not be deleted. Please try again'
                    ], JSON_PRETTY_PRINT);
                } else {
                    if ( database::$conn->affected_rows > 0 ) {
                        print $response =  json_encode([
                            'status' => true,
                            'message' => database::$conn->affected_rows
                        ], JSON_PRETTY_PRINT);
                    } else {
                        print $response =  json_encode([
                            'status' => false,
                            'message' => 'Sorry this curriculum item could not be deleted. Please try again'
                        ], JSON_PRETTY_PRINT);
                    }
                }
             }
         }
    } // END class ClassName 
    // 
    $AdminPortal = new AdminPortal();

?>