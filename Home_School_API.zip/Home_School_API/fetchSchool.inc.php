<?php 


 function getSchoolList() {
    if (isset($_GET['getSchoolList'])) {

        // $host         = "localhost"; // online
        // $userName     = "tammacor_covid19"; // online
        // $dB_Password  = "schoolmass_covid-19@tamma"; // online
        // $dB_Name      = "tammacor_schoolmass_covid-19"; // online


        $host         = "localhost"; // local
        $userName     = "covid-19"; // local
        $dB_Password  = "schoolmass_covid-19@tamma"; // local
        $dB_Name      = "schoolmass _covid-19"; // local


        $conn = new mysqli($host, $userName, $dB_Password, $dB_Name);

        $key   = htmlspecialchars(addslashes($_GET['getSchoolList']));
        $query = $conn->query(" SELECT `School_Name` FROM `ministry_prefered_school_list` WHERE `School_Name`  LIKE '%$key%' ");
        // 
        if ($query == false) {
            $response =  json_encode([
                'status' => false,
                'message' => 'Sorry school list could not be retrieved'
            ], JSON_PRETTY_PRINT);
        } else {
            if ($query->num_rows > 0) {
                $data = [];
                while ($row = $query->fetch_assoc()) {
                    $data[] = $row["School_Name"];
                }
                // 
                $response =  json_encode([
                    'status' => true,
                    'message' => $data
                ], JSON_PRETTY_PRINT);
            } else {
                $response =  json_encode([
                    'status' => true,
                    'message' => ['Sorry, no results found']
                ], JSON_PRETTY_PRINT);
            }
            
            
        }
        // 
        return print $response;
    }
 }

 getSchoolList();

?>