<?php 
  /**
   * *********************************************************************************************************
   * @_forProject:  Application | Developed By: TAMMA CORPORATION
   * @_purpose: (Please Specify) 
   * @_version Release: package_two
   * @_created Date: 00/00/2019
   * @_author(s):
   *   1) Mr. Michael kaiva Nimley. (Hercules d Newbie)
   *      @contact Phone: (+231) 777-007-009
   *      @contact Mail: michaelkaivanimley.com@gmail.com, mnimley6@gmail.com, mnimley@tammacorp.com
   *   --------------------------------------------------------------------------------------------------
   *   2) Fullname of engineer. (Code Name)
   *      @contact Phone: (+231) 000-000-000
   *      @contact Mail: -----@tammacorp.com
   * *********************************************************************************************************
   */
  require_once('../db.inc.php');
  
  /**
  * undocumented class
  *
  * @package default
  * @author 
  **/
  class teacherPortal 
  {
  
      /**
       * undocumented function
       *
       * @return void
       * @author 
       **/
       public function __construct()
       {
            $this->getAssignedClass();
            $this->fetchStudentsInquiry();
            $this->fetchInquiryByIndex();
            $this->replyToQuestion();
            $this->deleteQuestion();

            $this->fileUpload();
            $this->getTask();
            $this->addTask();
            $this->editTask();
            $this->deleteTask();

            $this->studentPopulationPerClassChart();
            $this->studentQuestionChart();
            $this->totalTaskChart();

            // print_r( json_encode($this->getIdentifier()) );
       }

       protected function getIdentifier()
       {
            $query   = database::$conn->query(" SELECT * FROM `admin_account` ");
            $session = $_SESSION['user-session'];
            // 
            $output = [];
            while ($row = $query->fetch_assoc()) {
                $phone = $row['Phone_number'];
                if ( password_verify($phone, $session) ) {
                     array_push(
                        $output,
                        [
                            'First_Name'       => $row['First_Name'],
                            'Last_Name'        => $row['Last_Name'],
                            'Gender'           => $row['Gender'],
                            'Phone_number'     => $row['Phone_number'],
                            'School_Teaching'  => $row['School_Teaching'],
                            'classes_taught'   => $row['classes_taught'],
                            'subject'          => $row['subject'],
                        ]
                     );
                } else {
                    // $output[] = "false";
                }
            }

            return $output;
       }
       //    
       private function getAssignedClass() {
           if (isset($_GET['getAssignedClass'])) {
                $teacherData = $this->getIdentifier();
                $phone = $teacherData[0]['Phone_number'];

                $query = database::$conn->query("SELECT * FROM `admin_account` WHERE `Phone_number` = '$phone' ");
                // 
                if ($query == false) {
                    $response =  json_encode([
                        'status' => false,
                        'message' => 'Sorry assigned classes could not be fetched'
                    ], JSON_PRETTY_PRINT);
                } else {
                    if ($query->num_rows == 1) {
                        // 
                        $data = $query->fetch_assoc();
                        // 
                        $response =  json_encode([
                            'status' => true,
                            'message' => [
                                'school' => $data['School_Teaching'],
                                'classes' => $data['classes_taught'],
                                'subjects' => $data['subject']
                                
                            ]
                        ], JSON_PRETTY_PRINT);
                    } else {
                        $response =  json_encode([
                            'status' => false,
                            'message' => 'Sorry assigned classes not available'
                        ], JSON_PRETTY_PRINT);
                    }
                }
                // 
                return print $response;
            }
       }
       // 
       private function fetchStudentsInquiry()
       {
           if (isset($_GET['getStudentsInquiry'])) {
                $teacherData = $this->getIdentifier();
                $identifier = $teacherData[0]['Phone_number'];
                $query = database::$conn->query(" SELECT * FROM `ask_teacher` WHERE teacherPhone  = '$identifier' ");

                if ($query == false) {
                    $response =  json_encode([
                        'status' => false,
                        'message' => 'Sorry Students Inquiry retrieval failed'
                    ], JSON_PRETTY_PRINT);
                } else {
                    if ($query->num_rows > 0 ) {

                        $id  = [];
                        $studentName  = [];
                        $Question = [];
                        $teacher_response = [];
                        while ($row = $query->fetch_assoc()) {
                            $id[]                =  $row["id"];
                            $studentName[]       =  $row["studentName"];
                            $Question[]          =  htmlspecialchars_decode(stripslashes($row["Question"]));
                            $teacher_response[]  =  $row["teacher_response"]; 
                        }
                        // 
                        $response =  json_encode([
                            'status' => true,
                            'message' => [
                                'ids'          =>  $id,
                                'studentName'  =>  $studentName,
                                'questions'    =>  $Question,
                                'reponses'     =>  $teacher_response,
                            ]
                        ], JSON_PRETTY_PRINT);
                    } else {
                        $response =  json_encode([
                            'status' => false,
                            'message' => '<div class="col alert-info p-3 mt-5"><b>NOTE:</b> Your students have not made any inquiry</div>'
                        ], JSON_PRETTY_PRINT);
                    }
                    
                }
            
            return print $response;
           }
       }
       //    
       private function fetchInquiryByIndex()
       {
           if (isset($_GET['index'])) {
            $identifier = htmlspecialchars(addslashes($_GET['index']));
            $query = database::$conn->query(" SELECT * FROM `ask_teacher` WHERE id  = '$identifier' ");

            if ($query == false) {
                $response =  json_encode([
                    'status' => false,
                    'message' => 'Sorry Students Inquiry retrieval for reply failed'
                ], JSON_PRETTY_PRINT);
            } else {
                if ($query->num_rows == 1 ) {
                    $row = $query->fetch_assoc();
                    // 
                    $response =  json_encode([
                        'status' => true,
                        'message' => [
                            'id'          =>   $row["id"],
                            'studentName'  =>  $row["studentName"],
                            'questions'    =>  $row["Question"],
                            'reponses'     =>  htmlspecialchars_decode($row["teacher_response"]),
                        ]
                    ], JSON_PRETTY_PRINT);
                } else {
                    $response =  json_encode([
                        'status' => false,
                        'message' => 'Sorry, this record no longer exist'
                    ], JSON_PRETTY_PRINT);
                }
            }
            // 
            return print $response;
           }
       }
       //    
       private function replyToQuestion()
       {
          if (isset($_POST['replyToQuestion'])) {
            $questionIndex  =  htmlspecialchars(addslashes($_POST['replyToQuestion']));
            $reply          =  htmlspecialchars(addslashes($_POST['reply']));
            // 
            $query = database::$conn->query(" UPDATE `ask_teacher` SET `teacher_response` = '$reply' WHERE id  = '$questionIndex' ");
            // 
            if ($query == false) {
                $response =  json_encode([
                    'status' => false,
                    'message' => 'Sorry question could not be replied to'
                ], JSON_PRETTY_PRINT);
            } else {
                // 
                $response =  json_encode([
                    'status' => true,
                    'message' => ''
                ], JSON_PRETTY_PRINT);
            }
            // 
            return print $response;
          }
       }
       //    
       private function deleteQuestion()
       {
          if (isset($_POST['deleteQuestion'])) {
            $questionIndex  =  htmlspecialchars(addslashes($_POST['deleteQuestion']));
            // 
            $query = database::$conn->query(" DELETE FROM `ask_teacher` WHERE id  = '$questionIndex' ");
            // 
            if ($query == false) {
                $response =  json_encode([
                    'status' => false,
                    'message' => 'Sorry question could not be DELETED'
                ], JSON_PRETTY_PRINT);
            } else {
                // 
                $response =  json_encode([
                    'status' => true,
                    'message' => ''
                ], JSON_PRETTY_PRINT);
            }
            // 
            return print $response;
          }
       }

       public function fileUpload()
       {
           if (isset($_POST['fileUpload'])) {
              $extension = $_POST['extension'];
              $fileName = $_POST['fileName'];
              $fileContents = base64_decode($_POST['fileUpload']);

              file_put_contents("uploads/".$fileName.'.'.$extension, $fileContents);

              if ( empty(file_get_contents("uploads/".$fileName.'.'.$extension)) ) {
                  print $response =  json_encode([
                      'status' => false,
                      'message' => 'Sorry '.$fileName.' upload failed'
                  ], JSON_PRETTY_PRINT);
              } else {
                  print $response =  json_encode([
                      'status' => true,
                      'message' => [
                          "url" => "config/uploads/".$fileName.'.'.$extension,
                          "filename" => $fileName
                      ]
                  ], JSON_PRETTY_PRINT);
              }
           }
       }


       //    
       private function getTask()
       {
            if (isset($_GET['getTask'])) {
                $teacherData = $this->getIdentifier();
                $phone       = $teacherData[0]['Phone_number'];
                $query = '';
                // fetch all task
                if (empty($_GET['id'])) {
                    $query = database::$conn->query(" SELECT * FROM `task` WHERE `addedBy` = '$phone' ");
                }
                // fetch specific task 
                else {
                    $id = htmlspecialchars(addslashes($_GET['id']));
                    $query = database::$conn->query(" SELECT * FROM `task` WHERE `addedBy` = '$phone' AND `id` = '$id' ");
                }
                //
                if ($query == false) {
                    $response =  json_encode([
                        'status' => false,
                        'message' => 'Sorry task could not be fetched'. database::$conn->error
                    ], JSON_PRETTY_PRINT);
                } else {
                    if ($query->num_rows > 0) {
                        // get task data simply for display
                        if (empty($_GET['id'])) {
                            //    
                            $id               =  []; 
                            $taskType         =  []; 
                            $intendedSchool   =  [];
                            $intendedClass    =  [];
                            $taskDescription  =  [];
                            $subject          =  [];
                            // 
                            while ($row = mysqli_fetch_assoc($query)) {
                                $id[]               =  $row["id"]; 
                                $taskType[]         =  $row["taskType"]; 
                                $intendedSchool[]   =  $row["intendedSchool"];
                                $intendedClass[]    =  $row["intendedClass"];
                                $subject[]          =  $row["subject"];
                                $taskDescription[]  =  htmlspecialchars_decode(stripslashes($row["taskDescription"]));
                            }
                            // 
                            $response =  json_encode([
                                'status' => true,
                                'message' => [
                                    'id'               =>  $id,
                                    'taskType'         =>  $taskType,
                                    'intendedSchool'   =>  $intendedSchool,
                                    'intendedClass'    =>  $intendedClass,
                                    'subject'          =>  $subject,
                                    'taskDescription'  =>  $taskDescription
                                ]
                            ], JSON_PRETTY_PRINT);
                        } 
                        // fetch specific task and exercises for edit
                        else {
                            $task = [];
                            while ($row = mysqli_fetch_assoc($query)) {
                                $id = $row["id"];
                                $query2 = database::$conn->query(" SELECT * FROM `exercise2` WHERE `taskId` = '$id' ");
                                // 
                                $exercise = [];
                                while ($row2 = mysqli_fetch_assoc($query2)) {
                                    array_push(
                                        $exercise,
                                        [
                                            'question_id'    => $row2['id'],
                                            'test_question'  => $row2['test_question'],
                                            'WrongAnswer1'   => $row2['WrongAnswer1'],
                                            'WrongAnswer2'   => $row2['WrongAnswer2'],
                                            'WrongAnswer3'   => $row2['WrongAnswer3'],
                                            'CorrectAnswer'  => $row2['CorrectAnswer'],
                                        ]
                                    );
                                }
                                // 
                                array_push(
                                    $task, 
                                    [
                                        'id'               => $row["id"],
                                        'taskType'         => $row["taskType"],
                                        'intendedSchool'   => $row["intendedSchool"],
                                        'intendedClass'    => $row["intendedClass"],
                                        'subject'          => $row["subject"],
                                        'files'            => $row["files"],
                                        'taskDescription'  => htmlspecialchars_decode(stripslashes($row["taskDescription"])),
                                        'exercise'         => $exercise
                                    ]
                                );
                                $exerciseArr = []; // empty array
                            }
                            // 
                            $response =  json_encode([
                                'status' => true,
                                'message' => $task
                            ], JSON_PRETTY_PRINT);
                        }
                    } else {
                        $response =  json_encode([
                            'status' => false,
                            'message' => 'Sorry task could not be fetched'
                        ], JSON_PRETTY_PRINT);
                    }
                }
                // 
                return print $response;
            }
       }
       //    
       private function addTask()
       {
           if (isset($_POST['addTask'])) {
                $taskType          =  htmlspecialchars(addslashes($_POST["taskType"]));
                $taskDescription   =  htmlspecialchars(addslashes($_POST["taskDescription"]));
                $intendedSchool    =  htmlspecialchars(addslashes($_POST["intendedSchool"]));
                $intendedClass     =  htmlspecialchars(addslashes($_POST["intendedClass"]));
                $intendedSubject   =  htmlspecialchars(addslashes($_POST["intendedSubject"]));
                $files             =  htmlspecialchars(addslashes($_POST["files"]));
                $teacherData = $this->getIdentifier();
                $phone = $teacherData[0]['Phone_number'];
                // 
                $addTest = (empty($_POST["testData"])) ? false : true;

                // 
                $query1 = database::$conn->query("INSERT INTO 
                    `task` (
                        `taskType`,
                        `intendedSchool`,
                        `intendedClass`,
                        `subject`,
                        `taskDescription`,
                        `files`,
                        `addedBy`
                    ) 
                    VALUES (
                        '$taskType',
                        '$intendedSchool',
                        '$intendedClass',
                        '$intendedSubject',
                        '$taskDescription',
                        '$files',
                        '$phone'
                    ) 
                ");
                // 
                if ($query1 == false) {
                    $response =  json_encode([
                        'status' => false,
                        'message' => 'Sorry Task could not be created. Error: ' . database::$conn->error
                    ], JSON_PRETTY_PRINT);
                } else {
                    if (database::$conn->affected_row == 1) {
                        if ($addTest == true) {
                            $testData = $_POST["testData"];
                            $taskId = database::$conn->insert_id;

                            $query  = "";

                            // 
                            for ($index=0; $index < count($testData); $index++) { 
                                // 
                                $test_question  =  $testData[$index]["test_question"];
                                $WrongAnswer1   =  $testData[$index]["WrongAnswer1"];
                                $WrongAnswer2   =  $testData[$index]["WrongAnswer2"];
                                $WrongAnswer3   =  $testData[$index]["WrongAnswer3"];
                                $CorrectAnswer  =  $testData[$index]["CorrectAnswer"];

                                // 
                                $query = database::$conn->query(" INSERT INTO 
                                    `exercise2` (
                                        `taskId`,
                                        `intendedSchool`,
                                        `intendedClass`,
                                        `addedBy`,
                                        `test_question`,
                                        `WrongAnswer1`,
                                        `WrongAnswer2`,
                                        `WrongAnswer3`,
                                        `CorrectAnswer`
                                    ) 
                                    VALUE (
                                        '$taskId',
                                        '$intendedSchool',
                                        '$intendedClass',
                                        '$phone',
                                        '$test_question',
                                        '$WrongAnswer1',
                                        '$WrongAnswer2',
                                        '$WrongAnswer3',
                                        '$CorrectAnswer'
                                    )
                                ") or die(database::$conn->error);
                            }


                            if ($query == true) {
                                $response =  json_encode([
                                    'status' => true,
                                    'message' => $taskType . ' task has been added along with a '.count($testData).' question exercise' 
                                ], JSON_PRETTY_PRINT);
                            } else {
                                $response =  json_encode([
                                    'status' => false,
                                    'message' => 'Sorry Task Question could not be created'
                                ], JSON_PRETTY_PRINT);
                            }
                        } else {
                            print $response =  json_encode([
                                'status' => true,
                                'message' => $taskType . ' task has been added'
                            ], JSON_PRETTY_PRINT);
                        }
                    } else {
                        $response =  json_encode([
                            'status' => false,
                            'message' => 'Sorry Task could not be created. Please try again'
                        ], JSON_PRETTY_PRINT);
                    }
                }
                // 
                return print $response;
           }
       }
       //
       private function deleteTask()
       {
           if (isset($_POST['deleteTask'])) {
               $key = htmlspecialchars(addslashes($_POST['deleteTask']));
               $query = database::$conn->query(" DELETE FROM `task` WHERE  `id` = '$key' ");

               if ($query == false) {
                    $response =  json_encode([
                        'status' => false,
                        'message' => 'Sorry task could not be deleted'
                    ], JSON_PRETTY_PRINT);
               } else {
                   if (database::$conn->affected_rows > 0) {
                        $response =  json_encode([
                            'status' => true,
                            'message' => '1 task deleted'
                        ], JSON_PRETTY_PRINT);
                   } else {
                        $response =  json_encode([
                            'status' => false,
                            'message' => 'Sorry task could not be deleted'
                        ], JSON_PRETTY_PRINT);
                   }
               }
               return print $response;
           }
       }    

       //    
       private function editTask()
       {
           if (isset($_POST['editTask'])) {
                $id                =  htmlspecialchars(addslashes($_POST["id"]));
                $taskType          =  htmlspecialchars(addslashes($_POST["taskType"]));
                $taskDescription   =  htmlspecialchars(addslashes($_POST["taskDescription"]));
                $intendedSchool    =  htmlspecialchars(addslashes($_POST["intendedSchool"]));
                $intendedClass     =  htmlspecialchars(addslashes($_POST["intendedClass"]));
                $intendedSubject   =  htmlspecialchars(addslashes($_POST["intendedSubject"]));
                $files             =  htmlspecialchars(addslashes($_POST["files"]));
                $teacherData = $this->getIdentifier();
                $phone = $teacherData[0]['Phone_number'];
                // 
                $addTest = (empty($_POST["testData"])) ? false : true;
                // 
                $query1 = database::$conn->query("UPDATE `task` 
                    SET `taskType`         =  '$taskType',
                        `intendedSchool`   =  '$intendedSchool',
                        `intendedClass`    =  '$intendedClass',
                        `subject`          =  '$intendedSubject',
                        `taskDescription`  =  '$taskDescription',
                        `files`            =  '$files'
                    WHERE `id` = '$id'
                ");
                // 
                if ($query1 == false) {
                    $response =  json_encode([
                        'status' => false,
                        'message' => 'Sorry Task could not be updated. Error: ' . database::$conn->error
                    ], JSON_PRETTY_PRINT);
                } else {
                    if (database::$conn->affected_row == 1) {
                        if ($addTest == true) {
                            $testData = $_POST["testData"];
                            // $query  = "";
                            // 
                            for ($index=0; $index < count($testData); $index++) { 
                                // 
                                $test_question  =  htmlspecialchars(addslashes($testData[$index]["test_question"]));
                                $WrongAnswer1   =  htmlspecialchars(addslashes($testData[$index]["WrongAnswer1"]));
                                $WrongAnswer2   =  htmlspecialchars(addslashes($testData[$index]["WrongAnswer2"]));
                                $WrongAnswer3   =  htmlspecialchars(addslashes($testData[$index]["WrongAnswer3"]));
                                $CorrectAnswer  =  htmlspecialchars(addslashes($testData[$index]["CorrectAnswer"]));
                                // 
                                $query = database::$conn->query(" UPDATE `exercise2`
                                    SET
                                        `taskId`          =  '$id',
                                        `intendedSchool`  =  '$intendedSchool',
                                        `intendedClass`   =  '$intendedClass',
                                        `addedBy`         =  '$phone',
                                        `test_question`   =  '$test_question',
                                        `WrongAnswer1`    =  '$WrongAnswer1',
                                        `WrongAnswer2`    =  '$WrongAnswer2',
                                        `WrongAnswer3`    =  '$WrongAnswer3',
                                        `CorrectAnswer`   =  '$CorrectAnswer'
                                ") or die(database::$conn->error);
                            }
                            if ($query == true) {
                                $response =  json_encode([
                                    'status' => true,
                                    'message' => $taskType . ' task has been added along with a '.count($testData).' question exercise' 
                                ], JSON_PRETTY_PRINT);
                            } else {
                                $response =  json_encode([
                                    'status' => false,
                                    'message' => 'Sorry Task Question could not be created'
                                ], JSON_PRETTY_PRINT);
                            }
                        } else {
                            print $response =  json_encode([
                                'status' => true,
                                'message' => $taskType . ' task has been added'
                            ], JSON_PRETTY_PRINT);
                        }
                    } else {
                        $response =  json_encode([
                            'status' => false,
                            'message' => 'Sorry Task could not be created. Please try again'
                        ], JSON_PRETTY_PRINT);
                    }
                }
                // 
                return print $response;
           }
       }




       //    
       private function studentPopulationPerClassChart()
       {
           if (isset($_GET['studentPopulation'])) {
                $teacherData  =  $this->getIdentifier();
                $classes      =  $teacherData[0]['classes_taught'];
                $School       =  $teacherData[0]['School_Teaching'];
                $classArr     =  explode(';', $classes);

                // 
                $statsData = [];
                for ($index=0; $index < count($classArr)-1; $index++) { 
                    $class = $classArr[$index];
                    $query = database::$conn->query(" SELECT COUNT(*) FROM `participants` WHERE school = '$School' AND class = '$class' ");
                    // 
                    if ($query == false) {
                        $response =  json_encode([
                            'status' => false,
                            'message' => 'Sorry Student Population statistics could not be fetched'
                        ], JSON_PRETTY_PRINT);
                    } else {
                        if ($query->num_rows > 0) {
                            while ($row = $query->fetch_assoc()) {
                                array_push(
                                    $statsData,
                                    [
                                        'class'          => $class,
                                        'totalStudents'  => (int)$row['COUNT(*)']
                                    ]
                                );
                            }
                            // 
                            $response =  json_encode([
                                'status' => true,
                                'message' => $statsData
                            ], JSON_PRETTY_PRINT);

                        } else {
                            $response =  json_encode([
                                'status' => false,
                                'message' => 'Sorry Student Population statistics could not be fetched'
                            ], JSON_PRETTY_PRINT);
                        }
                    }
                }
                return print $response;
           }
       }
       //    
       private function studentQuestionChart()
       {
           if (isset($_GET['studentQuestion'])) {
                $teacherData  =  $this->getIdentifier();
                $classes      =  $teacherData[0]['classes_taught'];
                $phone        =  $teacherData[0]['Phone_number'];
                $classArr     =  explode(';', $classes);
                // 
                $statsData = [];
                for ($index=0; $index < count($classArr)-1; $index++) { 
                    $class = $classArr[$index];
                    // questions
                    $query = database::$conn->query(" SELECT COUNT(*), teacher_response FROM `ask_teacher` WHERE teacherPhone = '$phone' ");
                    // questions without answers
                    $query2 = database::$conn->query(" SELECT COUNT(*), teacher_response FROM `ask_teacher` WHERE teacherPhone = '$phone' AND teacher_response = '' ");
                }
                // 
                if ($query == false) {
                    $response =  json_encode([
                        'status' => false,
                        'message' => 'Sorry Student Questions statistics could not be fetched'. database::$conn->error
                    ], JSON_PRETTY_PRINT);
                } else {
                        $row                =  $query->fetch_assoc();
                        $row2               =  $query2->fetch_assoc();
                        // 
                        $total              =  $row['COUNT(*)'];
                        $totalNoAnwer       =  $row2['COUNT(*)'];
                        // 
                        $teacher_response   =  $row['teacher_response'];
                        // 
                        if ($total == 0) {
                            array_push(
                                $statsData,
                                [
                                    'questions_with_answer'     =>  0,
                                    'questions_without_answer'  =>  0
                                ]
                            );
                        } else {
                            array_push(
                                $statsData,
                                [
                                    'questions_with_answer'     =>  ($total - $totalNoAnwer),
                                    'questions_without_answer'  =>  (int)$totalNoAnwer
                                ]
                            );
                        }
                        // 
                        $response =  json_encode([
                            'status' => true,
                            'message' => $statsData
                        ], JSON_PRETTY_PRINT);
                }
                // 
                return print $response;
           }
       }
       //    
       private function totalTaskChart()
       {
           if (isset($_GET['totalTaskChart'])) {
                $teacherData  =  $this->getIdentifier();
                $phone        =  $teacherData[0]['Phone_number'];
                $School       =  $teacherData[0]['School_Teaching'];
                //  
                $taskTypeArr = [ 'Reading Exercise', 'Study Exercise', 'Pop Quiz', 'Homework' ];
                // 
                $statsData = [];
                for ($index=0; $index < count($taskTypeArr); $index++) { 
                    $taskType = $taskTypeArr[$index];
                    // 
                    $query = database::$conn->query(" SELECT COUNT(*) FROM `task` 
                        WHERE 
                            intendedSchool = '$School' 
                        AND 
                            taskType = '$taskType' 
                        AND 
                            addedBy = '$phone' 
                    ");
                    // 
                    if ($query == false) {
                        $response =  json_encode([
                            'status' => false,
                            'message' => 'Sorry Student Population statistics could not be fetched'
                        ], JSON_PRETTY_PRINT);
                    } else {
                        if ($query->num_rows > 0) {
                            while ($row = $query->fetch_assoc()) {
                                array_push(
                                    $statsData,
                                    [
                                        'task'   => $taskType,
                                        'total'  => (int)$row['COUNT(*)']
                                    ]
                                );
                            }
                            // 
                            $response =  json_encode([
                                'status' => true,
                                'message' => $statsData
                            ], JSON_PRETTY_PRINT);

                        } else {
                            $response =  json_encode([
                                'status' => false,
                                'message' => 'Sorry Student Population statistics could not be fetched'
                            ], JSON_PRETTY_PRINT);
                        }
                    }
                }
                return print $response;
           }
       }
  } // END class ClassName 
$teacherPortal = new teacherPortal();
?>