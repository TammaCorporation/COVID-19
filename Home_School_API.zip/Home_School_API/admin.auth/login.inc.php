<?php 
    /**
     * *********************************************************************************************************
     * @_forProject:  Application | Developed By: TAMMA CORPORATION
     * @_purpose: (Please Specify) 
     * @_version Release: package_two
     * @_created Date: 00/00/2019
     * @_author(s):
     *   1) Mr. Michael kaiva Nimley. (Hercules d Newbie)
     *      @contact Phone: (+231) 777-007-009
     *      @contact Mail: michaelkaivanimley.com@gmail.com, mnimley6@gmail.com, mnimley@tammacorp.com
     *   --------------------------------------------------------------------------------------------------
     *   2) Fullname of engineer. (Code Name)
     *      @contact Phone: (+231) 000-000-000
     *      @contact Mail: -----@tammacorp.com
     * *********************************************************************************************************
     */
    require_once('../db.inc.php');
    
    /**
    * undocumented class
    *
    * @package default
    * @author 
    **/
    class Login
    {
        /**
         * undocumented function
         *
         * @return void
         * @author 
         **/
         public function __construct()
         {
            $this->Authenticate_account();
            $this->lookupSession();
            $this->logOut();
         }
        //  
        private function Authenticate_account()
        {
            if (isset($_POST['auth'])) 
            {
            $Phone_number   =  htmlspecialchars(strip_tags($_POST['Phone_number']));
            $Password       =  htmlspecialchars(strip_tags($_POST['Password']));
            // 
            $query = database::$conn->query(" SELECT * FROM `admin_account` WHERE Phone_number = '$Phone_number' ");
            // 
            if ($query == false) {
                print json_encode([
                    'status' => false,
                    'message' => 'Sorry, Error encountered'
                ], JSON_PRETTY_PRINT);
                } else {
                // phone number matches
                if (mysqli_num_rows($query) > 0) {
                    $data = $query->fetch_object();
                    // password valid
                    if (password_verify($Password, $data->Password)) {
                        // 
                        $session = password_hash($Phone_number, PASSWORD_DEFAULT);
                        $_SESSION['user-session'] = $session;
                        $session = $_SESSION['user-session'];

                        print json_encode([
                            'status' => true,
                            'message' => 'Welcome <b>'. $data->First_Name .'</b>',
                            'xxx' => password_hash($data->Account_Type_Code, PASSWORD_DEFAULT),
                            'accountType' => ($data->Account_Type_Code == "MOE_1416") ? 1 : 0
                        ], JSON_PRETTY_PRINT);
                    }
                    // password invalid 
                    else {
                        print json_encode([
                            'status' => false,
                            'message' => 'Sorry, Invalid credentials'
                        ], JSON_PRETTY_PRINT);
                    }
                } else {
                    print json_encode([
                        'status' => false,
                        'message' => 'Sorry, Invalid credentials'
                    ], JSON_PRETTY_PRINT);
                }
            }
            }
        }
        //  
        private function lookupSession() {
            if (isset($_POST['lookupSession'])) {
                // user is already logged in
                if ( isset($_SESSION['user-session']) && !empty($_SESSION['user-session']) ) 
                {
                    // 
                    $userType = $_POST['U_T'];
                    $query = database::$conn->query(" SELECT `educator` FROM `account_numbers` ");
                    // 
                    if ($query == false ) {
                        print json_encode([
                            'status' => false,
                            'message' => ''
                        ], JSON_PRETTY_PRINT);
                    } else {
                        while ($row = mysqli_fetch_assoc($query)) {
                            if ( password_verify($row['educator'], $userType) ) {
                                $response = json_encode([
                                    'status' => true,
                                    'message' => '',
                                    'accountType' => ($row['educator'] == "MOE_1416") ? 1 : 0
                                ], JSON_PRETTY_PRINT);
                                break;
                            } else {
                                $response = json_encode([
                                    'status' => false,
                                    'message' => ''
                                ], JSON_PRETTY_PRINT);                      
                            }
                        }
                        print $response;
                    }
                } 
                // user is not logged in
                else {
                    print json_encode([
                        'status' => false,
                        'message' => 'session is empty'
                    ], JSON_PRETTY_PRINT);
                }
            }
        }
        //  
        private function logOut() {
            if (isset($_POST['logOut'])) {
                // 
                if ( !empty($_SESSION['user-session']) ) {
                    session_destroy();
                    print true;
                } else {
                    print true;
                }
            }
        }

    } // END class ClassName 

    // 
    $Login = new Login();

?>