<?php 
    /**
     * *********************************************************************************************************
     * @_forProject:  Application | Developed By: TAMMA CORPORATION
     * @_purpose: (Please Specify) 
     * @_version Release: package_two
     * @_created Date: 00/00/2019
     * @_author(s):
     *   1) Mr. Michael kaiva Nimley. (Hercules d Newbie)
     *      @contact Phone: (+231) 777-007-009
     *      @contact Mail: michaelkaivanimley.com@gmail.com, mnimley6@gmail.com, mnimley@tammacorp.com
     *   --------------------------------------------------------------------------------------------------
     *   2) Fullname of engineer. (Code Name)
     *      @contact Phone: (+231) 000-000-000
     *      @contact Mail: -----@tammacorp.com
     * *********************************************************************************************************
     */
    require_once('../db.inc.php');
    
    /**
    * undocumented class
    *
    * @package default
    * @author 
    **/
    class signUp
    {
        /**
         * undocumented function
         *
         * @return void
         * @author 
         **/
         public function __construct()
         {
            $this->createAccount();
         }

         public function createAccount()
         {
             if (isset($_POST['createAccount'])) 
             {
                $First_Name         =   htmlspecialchars(strip_tags($_POST['First_Name']));
                $Last_Name          =   htmlspecialchars(strip_tags($_POST['Last_Name']));
                $Gender             =   htmlspecialchars(strip_tags($_POST['Gender']));
                $Phone_number       =   htmlspecialchars(strip_tags($_POST['Phone_number']));
                $School_Teaching    =   htmlspecialchars(strip_tags($_POST['School_Teaching']));
                // $classes_taught     =   htmlspecialchars(strip_tags($_POST['classes_taught']));
                $Account_Type_Code  =   htmlspecialchars(strip_tags($_POST['Account_Type_Code']));
                $Password           =   password_hash( htmlspecialchars(strip_tags($_POST['Password'])), PASSWORD_DEFAULT);
                $terms              =   htmlspecialchars(strip_tags($_POST['terms']));
                

                $School_Teaching = (empty($School_Teaching)) ? "None": $School_Teaching;
                $classes_taught  = "";
                $subject         = "";

                if (empty($_POST['classes_taught'])) {
                    $classes_taught = "None";
                } else {
                    foreach ($_POST['classes_taught'] as $classes) {
                        $classes_taught .= $classes.';';
                    }
                }

                if (empty($_POST['subject'])) {
                    $subject = "None";
                } else {
                    foreach ($_POST['subject'] as $subjects) {
                        $subject .= $subjects.';';
                    }
                }
                
                

                // validate account type number
                $validate_account_type_number = database::$conn->query(" SELECT * FROM  `account_numbers` WHERE educator = '$Account_Type_Code' ");
                
                if (mysqli_num_rows($validate_account_type_number) < 1) {
                    print json_encode([
                        'status' => false,
                        'message' => 'Sorry <b>'.$First_Name.'</b>, The <b>Account Type Code</b> is invalid'
                    ], JSON_PRETTY_PRINT);
                } else {
                    //prevent redundant entry
                    $query = database::$conn->query(" INSERT INTO 
                        `admin_account` (
                        `First_Name`,
                        `Last_Name`,
                        `Gender`,
                        `Phone_number`,
                        `School_Teaching`,
                        `classes_taught`,
                        `subject`,
                        `Account_Type_Code`,
                        `Password`,
                        `terms`
                        ) 
                        VALUES (
                        '$First_Name',
                        '$Last_Name',
                        '$Gender',
                        '$Phone_number',
                        '$School_Teaching',
                        '$classes_taught',
                        '$subject',
                        '$Account_Type_Code',
                        '$Password',
                        '$terms'
                        ) 
                    ");
                    // 
                    if ($query == false) {
                        print json_encode([
                            'status' => false,
                            'message' => 'Sorry <b>'.$First_Name.'</b>, Your account was not created. Please try again '. database::$conn->error
                        ], JSON_PRETTY_PRINT);
                    } else {
                        print json_encode([
                            'status' => true,
                            'message' => 'Congratulation <b>'.$First_Name. '</b>, Your account was just created. <i>We\'re signing you in so please sit tight</i>.'
                        ], JSON_PRETTY_PRINT);
                    }
                }
             }
         }

    } // END class ClassName 

    // 
    $signUp = new signUp();

?>