<?php 
session_start();
date_default_timezone_set('Africa/Monrovia');

// echo '<pre>';
// var_dump($_SESSION);
// echo '</pre>';

  /**
   * *********************************************************************************************************
   * @_forProject:  | Developed By: TAMMA CORPORATION
   * @_purpose: (Please Specify) 
   * @_version Release: package_two
   * @_created Date: 00/00/2019
   * @_author(s):
   *   1) Mr. Michael kaiva Nimley. (Hercules d Newbie)
   *      @contact Phone: (+231) 777-007-009
   *      @contact Mail: michaelkaivanimley.com@gmail.com, mnimley6@gmail.com, mnimley@tammacorp.com
   *   --------------------------------------------------------------------------------------------------
   *   2) Fullname of engineer. (Code Name)
   *      @contact Phone: (+231) 000-000-000
   *      @contact Mail: -----@tammacorp.com
   * *********************************************************************************************************
   */
  
  /**
  * undocumented class
  *
  * @package default
  * @author 
  **/
  class database
  {
    public static $conn;

        // private $host         = "localhost"; // online
        // private $userName     = "tammacor_covid19"; // online
        // private $dB_Password  = "schoolmass_covid-19@tamma"; // online
        // private $dB_Name      = "tammacor_schoolmass_covid-19"; // online


        private $host         = "localhost"; // local
        private $userName     = "covid-19"; // local
        private $dB_Password  = "schoolmass_covid-19@tamma"; // local
        private $dB_Name      = "schoolmass _covid-19"; // local
  
    /**
     * undocumented function
     *
     * @return void
     * @author 
     **/
    public function __construct()
    {
        self::$conn = new mysqli($this->host, $this->userName, $this->dB_Password, $this->dB_Name);
        if (self::$conn->connect_error) : 
            $this->ConnectionFailure(self::$conn->connect_error); 
        endif;
    }

    
    public function ConnectionFailure($dB_Error) 
    {
        print '<div class="p-3 alert-danger"><b>Status:</b> '.$dB_Error.'  </div>';
    }

  } // END class ClassName 

  $database = new database();
?>