<?php 
    /**
     * *********************************************************************************************************
     * @_forProject:  Application | Developed By: TAMMA CORPORATION
     * @_purpose: (Please Specify) 
     * @_version Release: package_two
     * @_created Date: 00/00/2019
     * @_author(s):
     *   1) Mr. Michael kaiva Nimley. (Hercules d Newbie)
     *      @contact Phone: (+231) 777-007-009
     *      @contact Mail: michaelkaivanimley.com@gmail.com, mnimley6@gmail.com, mnimley@tammacorp.com
     *   --------------------------------------------------------------------------------------------------
     *   2) Fullname of engineer. (Code Name)
     *      @contact Phone: (+231) 000-000-000
     *      @contact Mail: -----@tammacorp.com
     * *********************************************************************************************************
     */
    require_once('../db.inc.php');
    
    /**
    * undocumented class
    *
    * @package default
    * @author 
    **/
    class certificate
    {
        /**
         * undocumented function
         *
         * @return void
         * @author 
         **/
         public function __construct()
         {
            $this->addcertificate();
         }

         public function addcertificate()
         {
             if (isset($_POST['addcertificate'])) 
             {
                $testTaker    =  htmlspecialchars(strip_tags($_POST['testTaker']));
                $class        =  htmlspecialchars(strip_tags($_POST['class']));
                $subject      =  htmlspecialchars(strip_tags($_POST['subject']));
                $score        =  htmlspecialchars(strip_tags($_POST['score']));

                //prevent redundant entry
                $query = database::$conn->query(" INSERT INTO 
                    `certificate` (
                        `owner`, 
                        `class`, 
                        `subject`, 
                        `score`
                    ) 
                    VALUES (
                        '$testTaker', 
                        '$class', 
                        '$subject', 
                        '$score'
                    ) 
                ");

                // 
                if ($query == false) {
                    print json_encode([
                        'status' => false,
                        'message' => [
                            'id' => ''
                        ]
                    ], JSON_PRETTY_PRINT);
                 } else {
                    print json_encode([
                        'status' => true,
                        'message' => [
                            'id' => password_hash(database::$conn->insert_id, PASSWORD_DEFAULT)
                        ]
                    ], JSON_PRETTY_PRINT);
                }
                

             }
         }
    } // END class ClassName 

    // 
    $certificate = new certificate();

?>