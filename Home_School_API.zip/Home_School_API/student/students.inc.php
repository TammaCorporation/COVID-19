<?php 
  /**
   * *********************************************************************************************************
   * @_forProject:  Application | Developed By: TAMMA CORPORATION
   * @_purpose: (Please Specify) 
   * @_version Release: package_two
   * @_created Date: 00/00/2019
   * @_author(s):
   *   1) Mr. Michael kaiva Nimley. (Hercules d Newbie)
   *      @contact Phone: (+231) 777-007-009
   *      @contact Mail: michaelkaivanimley.com@gmail.com, mnimley6@gmail.com, mnimley@tammacorp.com
   *   --------------------------------------------------------------------------------------------------
   *   2) Fullname of engineer. (Code Name)
   *      @contact Phone: (+231) 000-000-000
   *      @contact Mail: -----@tammacorp.com
   * *********************************************************************************************************
   */
  require_once('../db.inc.php');
  require_once('checkAnswers.inc.php');
  
  /**
  * undocumented class
  *
  * @package default
  * @author 
  **/
  class studentPortal extends checkAnswers
  {
  
      /**
       * undocumented function
       *
       * @return void
       * @author 
       **/
        public function __construct()
        {
            $this->getSubjectList();
            $this->addInquiry();
            $this->getInquiries();
            $this->updateInquiry();
            $this->deleteInquiry();
            $this->getInitialTaskList();
            $this->getSpecificTaskDetails();
            parent::correctAnswers();
        }
       
        //    
        private function getStudentDetails() {
            $username  =  $_SESSION['user-session'];
            $query     =  database::$conn->query("SELECT * FROM `participants` WHERE `UserName` = '$username' ");

            if ($query == false) {
                $response =  [
                    'status' => false,
                    'message' => 'student details fetch failed. Error: '. database::$conn->error
                ];
            } else {
                if ($query->num_rows > 0) {
                    $data = $query->fetch_object();
                    // 
                    $response =  [
                        'status' => true,
                        'message' => [
                            'id'        =>  $data->id,
                            'UserName'  =>  $data->UserName,
                            'Fullname'  =>  $data->Fullname,
                            'Mobile'    =>  $data->Mobile,
                            'Age'       =>  $data->Age,
                            'school'    =>  $data->school,
                            'class'     =>  $data->class
                        ]
                    ];
                } else {
                    $response =  [
                        'status' => false,
                        'message' => 'student details fetch returned 0 results'
                    ];
                }
            }
            return $response;
        }
        // 
        private function getSubjectList()
        {
            if (isset($_GET['getSubjectList'])) {
                // 
                $studentDetails  =  $this->getStudentDetails();
                $school          =  $studentDetails['message']['school'];
                $class           =  $studentDetails['message']['class'];
                // 
                $query = database::$conn->query("SELECT * FROM `admin_account` WHERE `School_Teaching` = '$school' AND `classes_taught` LIKE '%$class%'");
                // 
                if ($query == false) {
                    $response =  json_encode([
                        'status' => false,
                        'message' => 'Sorry, teacher fetch failed. error: ' . database::$conn->error
                    ], JSON_PRETTY_PRINT);
                } else {
                    if ($query->num_rows > 0) {

                        $arr = [];
                        while ($row = mysqli_fetch_assoc($query)) {
                            $subject = $row['subject'];
                            $subArr = explode(";", $subject);

                            array_push(
                                $arr,
                                [
                                    'fullname'    =>  $row['First_Name'] . ' ' . $row['Last_Name'],
                                    'phone'       =>  $row['Phone_number'],
                                    'subjects'    =>  $subArr
                                ]
                            );
                        }
                        $response =  json_encode([
                            'status' => true,
                            'message' => $arr
                        ], JSON_PRETTY_PRINT);

                    } else {
                        $response =  json_encode([
                            'status' => false,
                            'message' => 'Sorry, your class does not yet have any teachers'
                        ], JSON_PRETTY_PRINT);
                    }
                    
                }
                return print $response;
            }
        }
        // 
        private function addInquiry() {
            if (isset($_POST['addInquiry'])) {
                if (
                    !empty($_POST['class']) ||
                    !empty($_POST['Qsubject']) ||
                    !empty($_POST['Question']) 
                ) {
                    // 
                    $studentDetails  =  $this->getStudentDetails();
                    // 
                    $studentId    =  $studentDetails['message']['id'];
                    $studentName  =  $studentDetails['message']['Fullname'];
                    $school       =  $studentDetails['message']['school'];
                    $class        =  htmlspecialchars(addslashes($_POST['class']));
                    $Qsubject     =  htmlspecialchars(addslashes($_POST['Qsubject']));
                    $Question     =  htmlspecialchars(addslashes($_POST['Question']));
                    // 
                    $query = database::$conn->query(" SELECT * FROM `admin_account` 
                        WHERE `School_Teaching` =    '$school' 
                        AND   `subject`         LIKE '%$Qsubject%' 
                        AND   `classes_taught`  LIKE '%$class%'   
                    ");
                    // 
                    if ($query == false) {
                        $response =  json_encode([
                            'status' => false,
                            'message' => 'Sorry, could not fetch teacher data'
                        ], JSON_PRETTY_PRINT);
                    } else {
                        if ($query->num_rows == 1) {
                            $data  = $query->fetch_object();
                            $phone = $data->Phone_number;
                            // 
                            $query = database::$conn->query("INSERT INTO 
                                `ask_teacher`(
                                    `studentId`,
                                    `studentName`,
                                    `teacherPhone`,
                                    `class`,
                                    `Qsubject`,
                                    `Question`
                                ) 
                                VALUE (
                                    '$studentId',
                                    '$studentName',
                                    '$phone',
                                    '$class',
                                    '$Qsubject',
                                    '$Question'
                                )
                            ");

                            if ($query == false) {
                                $response =  json_encode([
                                    'status' => false,
                                    'message' => 'Sorry, your question could not be added. Error: '.database::$conn->error
                                ], JSON_PRETTY_PRINT);
                            } else {
                                // 
                                if ( database::$conn->affected_rows == 1 ) {
                                    $response =  json_encode([
                                        'status' => true,
                                        'message' => '1 question added'
                                    ], JSON_PRETTY_PRINT);
                                } else {
                                    $response =  json_encode([
                                        'status' => false,
                                        'message' => 'Sorry, your question could not be added'
                                    ], JSON_PRETTY_PRINT);
                                }
                            }
                        } else {
                            $response =  json_encode([
                                'status' => false,
                                'message' => 'Sorry, there\'s no teacher available for this class'
                            ], JSON_PRETTY_PRINT);
                        }
                    }
                } else {
                    $response =  json_encode([
                        'status' => false,
                        'message' => 'Sorry, the parameters {class}, {Qsubject}, {Question} must be set inorder to complete this action'
                    ], JSON_PRETTY_PRINT);
                }
                return print $response;
            }
        }
        //    
        private function getInquiries() {
           if (isset($_GET['getInquiries'])) {
                // 
                $studentDetails  =  $this->getStudentDetails();
                $id              =  $studentDetails['message']['id'];
                $query           =  "";

                // fetch specific question
                if (isset($_GET['id']) && !empty($_GET['id'])) {
                    $searchId = htmlspecialchars(addslashes($_GET['id']));
                    $query = database::$conn->query("SELECT * FROM `admin_account` 
                        LEFT JOIN `ask_teacher` 
                        ON `ask_teacher`.teacherPhone =`admin_account`.Phone_number
                        WHERE `ask_teacher`.id = '$searchId' 
                    ");
                } 
                // fetch all questions
                else {
                    $query = database::$conn->query("SELECT * FROM `admin_account` 
                        LEFT JOIN `ask_teacher` 
                        ON `ask_teacher`.teacherPhone =`admin_account`.Phone_number
                        WHERE `ask_teacher`.studentId = '$id' 
                    ");
                }

                // 
                if ($query == false) {
                    $response =  json_encode([
                        'status' => false,
                        'message' => 'Sorry, questions fetch failed'
                    ], JSON_PRETTY_PRINT);
                } else {
                    if ($query->num_rows > 0) {
                        // 
                        $arr = [];
                        // 
                        while ( $row = mysqli_fetch_assoc($query) ) {
                            array_push(
                                $arr,
                                [
                                    'id'                  =>  $row['id'],
                                    'studentName'         =>  $row['studentName'],
                                    'intended_subject'    =>  $row['Qsubject'],
                                    'student_question'    =>  $row['Question'],
                                    'teacher_answer'      =>  $row['teacher_response'],
                                    'teacher_first_name'  =>  $row['First_Name'],
                                    'teacher_last_name'   =>  $row['Last_Name'],
                                    'teacher_phone'       =>  $row['teacherPhone'],
                                    'teacher_gender'      =>  $row['Gender']
                                ]
                            );
                        }
                        // 
                        $response =  json_encode([
                            'status' => true,
                            'message' => $arr
                        ], JSON_PRETTY_PRINT);
                    } else {
                        $response =  json_encode([
                            'status' => false,
                            'message' => 'Sorry no questions have been posted'
                        ], JSON_PRETTY_PRINT);
                    }
                }
                // 
                return print $response;
            }
        }
        //
        private function updateInquiry() {
            if (isset($_POST['updateInquiry'])) {
                // 
                if (
                    empty($_POST['id'])           ||
                    empty($_POST['studentName'])  ||
                    empty($_POST['teacherPhone']) ||
                    empty($_POST['Qsubject'])     ||
                    empty($_POST['Question'])     ||
                    empty($_POST['teacher_response'])
                    ) {
                    $response =  json_encode([
                        'status' => false,
                        'message' => 'Sorry, these parameters: {studentName}, {teacherPhone}, 
                        {class}, {Qsubject}, {Question}, {teacher_response} must be set inorder 
                        to complete this action'
                    ], JSON_PRETTY_PRINT);
                }
                else {
                    // 
                    $id                =  htmlspecialchars(addslashes($_POST['id']));
                    $studentName       =  htmlspecialchars(addslashes($_POST['studentName']));
                    $teacherPhone      =  htmlspecialchars(addslashes($_POST['teacherPhone']));
                    $Qsubject          =  htmlspecialchars(addslashes($_POST['Qsubject']));
                    $Question          =  htmlspecialchars(addslashes($_POST['Question']));
                    $teacher_response  =  htmlspecialchars(addslashes($_POST['teacher_response']));	
                    // 
                    $query = database::$conn->query("UPDATE `ask_teacher`
                        SET `studentName`      =  '$studentName', 
                            `teacherPhone`     =  '$teacherPhone', 
                            `Qsubject`         =  '$Qsubject', 
                            `Question`         =  '$Question', 
                            `teacher_response` =  '$teacher_response' 
                        WHERE `id`             =  '$id' 
                    ");
                    // 
                    if ($query == false) {
                        $response =  json_encode([
                            'status' => false,
                            'message' => 'Sorry, update failed. Error: '.database::$conn->error
                        ], JSON_PRETTY_PRINT);
                    } else {
                        // 
                        if ( database::$conn->affected_rows == 1 ) {
                            $response =  json_encode([
                                'status' => true,
                                'message' => '1 record updated'
                            ], JSON_PRETTY_PRINT);
                        } else {
                            $response =  json_encode([
                                'status' => false,
                                'message' => 'No changes were made'
                            ], JSON_PRETTY_PRINT);
                        }
                    }
                }
                // 
                return print $response;
            }
        }
        //
        private function deleteInquiry() {
            if (isset($_POST['deleteInquiry'])) {
                // 
                if (empty($_POST['id'])) {
                    $response =  json_encode([
                        'status' => false,
                        'message' => 'Sorry, the record {id} must be set inorder to complete this action'
                    ], JSON_PRETTY_PRINT);
                } else {
                    $id = htmlspecialchars(addslashes($_POST['id']));
                    // 
                    $query = database::$conn->query("DELETE FROM `ask_teacher` WHERE id = '$id' ");
                    // 
                    if ($query == false) {
                        $response =  json_encode([
                            'status' => false,
                            'message' => 'Sorry, question delete action failed. Error: '.database::$conn->error
                        ], JSON_PRETTY_PRINT);
                    } else {
                        if (database::$conn->affected_rows == 1) {
                            $response =  json_encode([
                                'status' => true,
                                'message' => '1 record have been deleted'
                            ], JSON_PRETTY_PRINT);
                        } else {
                            $response =  json_encode([
                                'status' => false,
                                'message' => 'Sorry, could not delete question. record with id of: '. $id .' does not exist'
                            ], JSON_PRETTY_PRINT);
                        }
                    }
                }
                return print $response;
            }
        }




        // 
        private function getInitialTaskList() {
            if (isset($_GET['getInitialTaskList'])) {
                $data   = $this->getStudentDetails();
                $school = $data['message']['school'];
                // 
                $query = database::$conn->query("SELECT distinct `subject`, `intendedSchool`  FROM `task` WHERE `intendedSchool` = '$school'");
                // 
                if ($query == false) {
                    $response =  json_encode([
                        'status' => false,
                        'message' => 'Sorry, could not retrieve subject list'
                    ], JSON_PRETTY_PRINT);
                } else {
                    if ($query->num_rows > 0) {
                        //
                        $subject = [];
                        while ($row = mysqli_fetch_assoc($query)) {
                            $subject[] =  $row['subject'];
                        }
                        // 
                        $subjectsAndTotals = $this->getTotalTaskCount($subject, $school);
                        // 
                        $response =  json_encode([
                            'status' => true,
                            'message' => $subjectsAndTotals
                        ], JSON_PRETTY_PRINT);
                    } else {
                        $response =  json_encode([
                            'status' => false,
                            'message' => '0 records found'
                        ], JSON_PRETTY_PRINT);
                    }
                }
                return print $response;
            }
        }
        // 
        private function getTotalTaskCount($subjects, $school) {
            // 
            $total = [];
            for ($i=0; $i < count($subjects); $i++) { 
                $subject = $subjects[$i];
                // 
                $query = database::$conn->query("SELECT * FROM `task` 
                    WHERE `intendedSchool` = '$school' 
                    AND   `subject`        = '$subject' 
                ");
                // 
                if ($query == false) {
                    return print [
                        'status' => false,
                        'message' => 'Sorry, could not retrieve subject stats'
                    ];
                } else {
                    if ($query->num_rows > 0) {
                        // 
                        array_push(
                            $total,
                            [
                                'subject' => $subject, 
                                'total' => $query->num_rows
                            ]
                        );
                    } else {
                        return print [
                            'status' => false,
                            'message' => '0 records found'
                        ];
                    }
                }
            }
            return $total;

        }
        // 
        private function getSpecificTaskDetails()
        {
            if (isset($_GET['getSpecificTaskDetails'])) {
                // 
                if (empty($_GET['subject'])) {
                    $response =  json_encode([
                        'status' => false,
                        'message' => 'Sorry, the parameter {subject} must be set inorder to complete this action'
                    ], JSON_PRETTY_PRINT);
                } else {
                    $subject = htmlspecialchars(addslashes($_GET['subject']));
                    // 
                    $data   = $this->getStudentDetails();
                    $school = $data['message']['school'];
                    $class  = $data['message']['class'];
                    // 
                    $query = database::$conn->query("SELECT * FROM `task` 
                        WHERE `intendedSchool`  =  '$school'
                        AND   `intendedClass`   =  '$class'
                        AND   `subject`         =  '$subject'
                    ");
                    // 
                    if ($query == false) {
                        $response =  json_encode([
                            'status' => false,
                            'message' => 'Sorry, Tasks for '.$class.' '.$subject.' retrieval failed. Error: '.database::$conn->error
                        ], JSON_PRETTY_PRINT);
                    } else {
                        if ($query->num_rows > 0) {
                            $arr = [];
                            while ($row = mysqli_fetch_assoc($query)) {

                                $id = $row['id'];
                                $query2 = database::$conn->query(" SELECT * FROM `exercise2` WHERE `taskId` = '$id' ");
                                // exercise array
                                $exerciseArr = [];
                                while ($row2 = mysqli_fetch_assoc($query2)) {
                                    array_push(
                                        $exerciseArr,
                                        [
                                            'test_question' => $row2['test_question'],
                                            'WrongAnswer1'  => $row2['WrongAnswer1'],
                                            'WrongAnswer2'  => $row2['WrongAnswer2'],
                                            'WrongAnswer3'  => $row2['WrongAnswer3'],
                                            'CorrectAnswer' => $row2['CorrectAnswer']
                                        ]
                                    );
                                }
                                // task array with exercise attached
                                array_push(
                                    $arr,
                                    [
                                        'taskType'         =>  $row['taskType'],
                                        'subject'          =>  $row['subject'],
                                        'taskDescription'  =>  $row['taskDescription'],
                                        'files'            =>  $row['files'],
                                        'exercise'         =>  $exerciseArr,
                                        'addedBy'          =>  $row['addedBy']
                                    ]
                                );
                                $exerciseArr = []; // empty array
                                // 
                                $response =  json_encode([
                                    'status' => true,
                                    'message' => $arr
                                ], JSON_PRETTY_PRINT);
                            }
                        } else {
                            $response =  json_encode([
                                'status' => false,
                                'message' => 'Sorry, 0 Tasks for '.$class.' '.$subject.' retried'
                            ], JSON_PRETTY_PRINT);
                        }
                        
                    }
                }
                return print $response;
            }
        }



        

  } // END class ClassName 
$studentPortal = new studentPortal();
//   $checkAnswers = new checkAnswers();
?>