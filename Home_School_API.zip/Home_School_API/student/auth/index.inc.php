<?php 
    /**
     * *********************************************************************************************************
     * @_forProject: M.O.E Survey Application | Developed By: TAMMA CORPORATION
     * @_purpose: (Please Specify) 
     * @_version Release: package_two
     * @_created Date: 00/00/2019
     * @_author(s):
     *   1) Mr. Michael kaiva Nimley. (Hercules d Newbie)
     *      @contact Phone: (+231) 777-007-009
     *      @contact Mail: michaelkaivanimley.com@gmail.com, mnimley6@gmail.com, mnimley@tammacorp.com
     *   --------------------------------------------------------------------------------------------------
     *   2) Fullname of engineer. (Code Name)
     *      @contact Phone: (+231) 000-000-000
     *      @contact Mail: -----@tammacorp.com
     * *********************************************************************************************************
     */
    require_once('../db.inc.php');
    
    /**
    * undocumented class
    *
    * @package default
    * @author 
    **/
    class auth
    {
        /**
         * undocumented function
         *
         * @return void
         * @author 
         **/
         public function __construct()
         {
            $this->login();
            $this->adduser();
            $this->logOut();
         }

        //  
         private function login()
         {
             if (isset($_POST['login'])) {
                $UserName = $_POST['UserName'];
                $phone    = $_POST['phone'];
                // 
                $query = database::$conn->query(" SELECT * FROM `participants` WHERE `Mobile` = '$phone' ");

                // 
                if ($query == false) {
                    print json_encode([
                        'status' => false,
                        'message' => 'Sorry, Login Failed'
                    ], JSON_PRETTY_PRINT);
                } else {
                    if ($query->num_rows > 0) {
                        // 
                        $results = "";
                        $hash = "";
                        // 
                        while ($row = mysqli_fetch_assoc($query)) {
                            $potentials = $row['UserName'];
                            // 
                            if (password_verify($UserName, $potentials)) {
                                $results = "true";
                                $hash = $potentials;
                                break;
                            } else {
                                $results = "false";
                            }
                        }
                        // 
                        if ($results == "true") {
                            $query = database::$conn->query(" SELECT * FROM `participants` WHERE `UserName` = '$hash' ");

                            if ($query == false) {
                                print json_encode([
                                    'status' => false,
                                    'message' => 'Sorry, details fetch encountered an error'
                                ], JSON_PRETTY_PRINT);
                            } else {
                                $data = $query->fetch_object();

                                $_SESSION['user-session'] = $potentials;
                                $potentials = $_SESSION['user-session'];

                                // 
                                print json_encode([
                                    'status' => true,
                                    'message' => 'login successful',
                                    'data' => [
                                        'Fullname' =>  $data->Fullname,
                                        'Mobile'   =>  $data->Mobile,
                                        'Age'      =>  $data->Age,
                                        'School'   =>  $data->school,
                                        'Class'    =>  $data->class,
                                    ]
                                ], JSON_PRETTY_PRINT);
                            }
                        } else {
                            print json_encode([
                                'status' => false,
                                'message' => 'Sorry, invalid credentials'
                            ], JSON_PRETTY_PRINT);
                        }
                    } else {
                        print json_encode([
                            'status' => false,
                            'message' => 'Sorry, invalid credentials'
                        ], JSON_PRETTY_PRINT);
                    }
                    
                }
                

             }
         }

        //  
         private function adduser()
         {
             if (isset($_POST['addUser'])) 
             {
                $data        =  $_POST['data'];
                $singleVal   =  implode(",", $data);
                $singleVals  =  explode(",", $singleVal);

                $fullname    =  $singleVals[0];
                $UserName    =  password_hash($singleVals[1], PASSWORD_DEFAULT);
                $phone       =  $singleVals[2];
                $age         =  $singleVals[3];
                $school      =  $singleVals[4];
                $class       =  $singleVals[5];
                $follow      =  $singleVals[6];

                //prevent redundant entry
                $query = database::$conn->query(" SELECT * FROM `participants` WHERE `Fullname` = '$fullname' AND `Mobile` = '$phone' ");
                if (mysqli_num_rows($query) > 0) {
                    $data = $query->fetch_object();
                    print json_encode([
                        'status' => true,
                        'message' => 'data exists',
                        'data' => [
                            'Fullname' => $data->Fullname,
                            'Mobile' => $data->Mobile,
                            'Age' => $data->Age,
                            'School' => $data->school,
                            'Class' => $data->class,
                        ]
                    ], JSON_PRETTY_PRINT);
                 } else {
                    $query = database::$conn->query(" INSERT INTO 
                        `participants`(
                            `Fullname`, 
                            `UserName`,
                            `Mobile`, 
                            `Age`, 
                            `school`, 
                            `class`, 
                            `use_SchoolMass_after_Corona_Virus_Epidemic`
                        ) 
                        VALUES(
                           '$fullname', 
                           '$UserName',
                           '$phone', 
                           '$age', 
                           '$school',
                           '$class',
                           '$follow'
                        )
                    ") or die(database::$conn->error);
                    
                    if ($query == false) {
                        print json_encode([
                            'status' => false,
                            'message' => database::$conn->error,
                            'data' => []
                        ], JSON_PRETTY_PRINT);
                    } else {
                        print json_encode([
                            'status' => true,
                            'message' => 'user added',
                            'data' => []
                        ], JSON_PRETTY_PRINT);
                    }
                }
             }
         }

         private function logOut()
         {
            if (isset($_POST['logOut'])) {
                session_destroy();

                print true;
            }
         }
    } // END class ClassName 

    // 
    $auth = new auth();

?>