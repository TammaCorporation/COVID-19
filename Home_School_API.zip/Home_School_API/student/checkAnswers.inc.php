<?php 
  /**
   * *********************************************************************************************************
   * @_forProject: | Developed By: TAMMA CORPORATION
   * @_purpose: (Please Specify) 
   * @_version Release: package_two
   * @_created Date: 00/00/2019
   * @_author(s):
   *   1) Mr. Michael kaiva Nimley. (Hercules d Newbie)
   *      @contact Phone: (+231) 777-007-009
   *      @contact Mail: michaelkaivanimley.com@gmail.com, mnimley6@gmail.com, mnimley@tammacorp.com
   *   --------------------------------------------------------------------------------------------------
   *   2) Fullname of engineer. (Code Name)
   *      @contact Phone: (+231) 000-000-000
   *      @contact Mail: -----@tammacorp.com
   * *********************************************************************************************************
   */
//   require_once('../db.inc.php');

  
  /**
  * undocumented class
  *
  * @package default
  * @author 
  **/
  class checkAnswers 
  {
    // 
    public function correctAnswers()
    {
        if (isset($_POST['checkAnswers'])) {
            // parameters
            $questions            =  $_POST['questions'];
            $userSelectedOptions  =  $_POST['userSelectedOptions'];
            // validate answers
            $score   =   $this->validateAnswers($questions, $userSelectedOptions);
            $review  =   $this->generateTestReview($questions, $userSelectedOptions);
            // 
            print json_encode(array(
                'score' => $score[0],
                'points' => $score[1],
                'review' => $review
            ), JSON_PRETTY_PRINT);
        }
    }
    //
    public function validateAnswers(Array $questions, Array $userSelectedOptions)
    {
        // 
        for ($i=0; $i < count($questions); $i++) { 
            $q      = $questions[$i];
            $answer = $userSelectedOptions[$i];
            // 
            $query  = database::$conn->query(" SELECT * FROM `exercise2` WHERE `test_question` = '$q' AND `CorrectAnswer` = '$answer'  ");
            // wrong answer
            if (mysqli_num_rows($query) < 1) {
                $points[] = 0;
            }
            // correct answer 
            else {
                100 / mysqli_num_rows($query);
                $result = $query->fetch_assoc();
                $points[] = 100 / count($questions);
            }
        }
        return array(array_sum($points), $points);
    }
    //    
    public function generateTestReview(Array $questions, Array $userSelectedOptions)
    {
        //    
        $test_review = [];
        // 
        for ($i=0; $i < count($questions); $i++) { 
            $q      = $questions[$i];
            // 
            $query  = database::$conn->query(" SELECT * FROM `exercise2` WHERE `test_question` = '$q'  ");
            
            //
            while ($row = mysqli_fetch_assoc($query)) {
                array_push(
                    $test_review,
                    [
                        'question'       => $q,
                        'selectedAnswer' => $userSelectedOptions[$i],
                        'correctAnswer'  => $row['CorrectAnswer'],
                    ]
                );
            } 
        }
        return $test_review;
    }
  } // END class ClassName 
?>