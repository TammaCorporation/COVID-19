<!-- page header -->
<?php include('header.php'); ?>

<!-- page footer -->
<?php include('footer.php'); ?>