<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- bootstrap -->
    <link rel="stylesheet" href="assets/library/css/bootstrap/bootstrap.min.css">
    <!-- animation -->
    <link rel="stylesheet" href="assets/library/css/animation/animate.css">
    <!-- font-awesome -->
    <link rel="stylesheet" href="assets/library/css/font-awesome/all.css">
    <!-- generic stylesheet -->
    <link rel="stylesheet" href="assets/css/main.css">
    <title>SCHOOL-MASS COVID-19</title>
</head>
<body>