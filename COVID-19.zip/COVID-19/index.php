<!-- page header -->
<?php include('header.php'); ?>


<div class="container border animated slideInUp">
    <h1>hello</h1>
    <button>Test Js</button>
</div>


<!-- page footer -->
<?php include('footer.php'); ?>