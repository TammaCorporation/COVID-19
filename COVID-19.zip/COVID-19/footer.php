    <!--  -->
    <script src="assets/library/js/jquery/jquery.js"></script>
    <!--  -->
    <script src="assets/library/js/jquery/bootstrap.js"></script>
    <!--  -->
    <script src="assets/library/js/jquery/bootstrap.min.js"></script>
    <!--  -->
    <script src="assets/library/js/jquery/fontawesome-all.js"></script>
    <!--  -->
    <script src="assets/library/js/jquery/popper.min.js"></script>
    <!--  -->
    <script src="assets/js/main.js"></script>
</body>
</html>